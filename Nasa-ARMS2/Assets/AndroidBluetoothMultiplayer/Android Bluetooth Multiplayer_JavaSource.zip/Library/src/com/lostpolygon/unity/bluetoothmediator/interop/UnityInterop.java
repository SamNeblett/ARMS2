/*
 * Copyright (c) 2015, Lost Polygon. All rights reserved.
 * DO NOT ALTER OR REMOVE COPYRIGHT NOTICES OR THIS FILE HEADER.
 * 
 * This file is subject to Asset Store Terms of Service and EULA.
 * Please see http://unity3d.com/company/legal/as_terms for more information.
 */

package com.lostpolygon.unity.bluetoothmediator.interop;

import android.bluetooth.BluetoothDevice;

import com.lostpolygon.unity.bluetoothmediator.BluetoothMediator;
import com.unity3d.player.UnityPlayer;

/**
 * Wrapper class for sending string messages to Unity via UnityPlayer.UnitySendMessage().
 */
public class UnityInterop {

	/** The name of GameObject that will receive the callbacks. */
	private static final String UNITY_OBJECT = "AndroidBluetoothMultiplayer";

	/** Value indicating whether the Unity Activity presence test has already been done. */
	public static boolean mIsUnityPresenceChecked = false;

	/**
	 * Value indicating whether the Unity Activity is present and UnitySendMessage can be called.
	 */
	public static boolean mIsUnityPresent;

	/**
	 * Sends message to UNITY_OBJECT GameObject.
	 * 
	 * @param methodName
	 *            Method to call in UNITY_OBJECT.
	 * @param data
	 *            String data to be passed.
	 */
	public static void UnitySendMessage(String methodName, String data) {
		UnitySendMessage(UNITY_OBJECT, methodName, data);
	}

	/**
	 * Sends message to Unity GameObject objName.
	 * 
	 * @param objName
	 *            Name of GameObject which will receive the message.
	 * @param methodName
	 *            Method to call.
	 * @param data
	 *            String data to be passed.
	 */
	private static void UnitySendMessage(String objName, String methodName, String data) {
		// Run the test
		if (!mIsUnityPresenceChecked) {
			try {
				mIsUnityPresent = true;
				UnityPlayer.UnitySendMessage("", "", "");
			} catch (NoClassDefFoundError e) {
				mIsUnityPresent = false;
			}
			if (BluetoothMediator.isVerboseLog())
				LogHelper.log("Running under Unity player: " + (mIsUnityPresent ? "True" : "False"), UnityInterop.class);

			mIsUnityPresenceChecked = true;
		}

		// Send the message if running under Unity Activity
		if (!mIsUnityPresent)
			return;

		if (methodName == null) {
			LogHelper.logWarning("An attempt to call UnitySendMessage with null 'methodName' was detected. This should not happen, please report this.", UnityInterop.class);
			return;
		}

		if (data == null) {
			LogHelper.logWarning("An attempt to call UnitySendMessage with null 'data' was detected. This should not happen, please report this.", UnityInterop.class);
			return;
		}

		if (BluetoothMediator.isVerboseLog())
			LogHelper.log("Interop - Call event '" + methodName + "'", UnityInterop.class);

		UnityPlayer.UnitySendMessage(objName, methodName, data);
	}

	/**
	 * Helper class for serializing some Java types into strings for passing to Unity.
	 */
	public static class JavaToStringConverter {
		/**
		 * Constant delimiter for object values. Must be the same as in
		 * AndroidBluetoothMultiplayer.JavaMethods.cs
		 */
		public static final String DELIMITER = "~~~#$%~~~";

		/**
		 * Merges inputArray into a single string delimited with glueString.
		 * 
		 * @param inputArray
		 *            the input string array
		 * @param glueString
		 *            the glue string
		 * @return the string
		 */
		public static String implodeArray(String[] inputArray, String glueString) {

			/** Output variable */
			String output;

			if (inputArray != null && inputArray.length > 0) {
				StringBuilder sb = new StringBuilder(100);

				sb.append(inputArray[0]);
				for (int i = 1; i < inputArray.length; i++) {
					sb.append(glueString);
					sb.append(inputArray[i]);
				}

				output = sb.toString();
			} else {
				output = "";
			}

			return output;
		}

		/**
		 * Serializes BluetoothDevice into string.
		 * 
		 * @param device
		 *            The BluetoothDevice to serialize.
		 * @return The string representation of some {@link device} properties.
		 * 
		 * @see android.bluetooth.BluetoothDevice
		 */
		public static String BluetoothDevice(BluetoothDevice device) {
			String[] result = {
				device.getName(),
				device.getAddress(),
				Integer.toString(device.getBondState()),
				Integer.toString(device.getBluetoothClass().getDeviceClass()) };

			return implodeArray(result, DELIMITER);
		}
	}

}
