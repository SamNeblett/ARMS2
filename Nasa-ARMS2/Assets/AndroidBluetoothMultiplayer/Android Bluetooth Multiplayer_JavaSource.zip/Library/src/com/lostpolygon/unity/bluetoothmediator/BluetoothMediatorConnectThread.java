/*
 * Copyright (c) 2015, Lost Polygon. All rights reserved.
 * DO NOT ALTER OR REMOVE COPYRIGHT NOTICES OR THIS FILE HEADER.
 * 
 * This file is subject to Asset Store Terms of Service and EULA.
 * Please see http://unity3d.com/company/legal/as_terms for more information.
 */

package com.lostpolygon.unity.bluetoothmediator;

import java.io.IOException;

import com.lostpolygon.unity.bluetoothmediator.interop.LogHelper;

import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothSocket;

/**
 * Manages the process of connecting to the server and returns the result to BluetoothMediatorClient
 * instance.
 */
class BluetoothMediatorConnectThread extends Thread {

	/** The connection Bluetooth socket. */
	private final BluetoothSocket mSocket;

	/** The server Bluetooth device. */
	private final BluetoothDevice mDevice;

	/**
	 * The BluetoothMediatorClient instance that has created the thread. Connection result will be
	 * passed to it.
	 */
	public final BluetoothMediatorClient mBluetoothMediatorClient;

	/**
	 * Instantiates a new Bluetooth connection thread.
	 * 
	 * @param bluetoothMediatorClient
	 *            the BluetoothMediatorClient instance. Connection result will be passed to it.
	 */
	BluetoothMediatorConnectThread(BluetoothMediatorClient bluetoothMediatorClient) {
		super("BluetoothMediatorConnectThread ["
			+ bluetoothMediatorClient.getMediatorCallback().getSettings().hostDevice.getAddress() + "]");
		mBluetoothMediatorClient = bluetoothMediatorClient;

		mDevice = mBluetoothMediatorClient.getMediatorCallback().getSettings().hostDevice;

		BluetoothSocket tmp = null;
		// Get a BluetoothSocket for a connection to the given BluetoothDevice
		try {
			tmp = mDevice.createRfcommSocketToServiceRecord(mBluetoothMediatorClient.getMediatorCallback()
					.getSettings().uuid);
		} catch (IOException e) {
			if (BluetoothMediator.isVerboseLog()) {
				LogHelper.logError("Client - Socket createRfcommSocketToServiceRecord() failed", this, e);
			}
			// Notifying the client about the failure
			mBluetoothMediatorClient.onConnectToBluetoothServerFailed(tmp, mDevice);
		}

		mSocket = tmp;
	}

	/**
	 * @see java.lang.Thread#run()
	 */
	public void run() {
		if (BluetoothMediator.isVerboseLog())
			LogHelper.log("Client - Start ConnectThread", this);

		// Always cancel discovery because it will slow down a connection
		mBluetoothMediatorClient.getMediatorCallback().getAdapter().cancelDiscovery();

		// Make a connection to the BluetoothSocket
		try {
			// This is a blocking call and will only return on a
			// successful connection, error, or interruption
			mSocket.connect();
		} catch (IOException e) {
			// Error occurred, closing connections

			if (interrupted())
				return;

			// Close the socket
			try {
				if (mSocket != null)
					mSocket.close();
			} catch (IOException e2) {
				LogHelper.logError("Client - Unable to close() socket during connection failure", this, e);
			}
			if (BluetoothMediator.isVerboseLog()) {
				LogHelper.logError("Client - Connection failed", this, e);
			}

			// Notifying the client about the failure
			mBluetoothMediatorClient.onConnectToBluetoothServerFailed(mSocket, mDevice);

			return;
		}

		if (interrupted())
			return;

		// Start the connected thread on successful connection
		mBluetoothMediatorClient.onConnectToBluetoothServer(mSocket, mDevice);
	}

	/**
	 * Cancel the connection.
	 */
	public void cancel() {
		try {
			mSocket.close();
		} catch (IOException e) {
			// We don't care about exception as we won't need that socket anyway

			// Log.e(TAG, "close() of connect " + mSocketType + " socket failed", e);
		}
	}
}
