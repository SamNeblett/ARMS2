/*
 * Copyright (c) 2015, Lost Polygon. All rights reserved.
 * DO NOT ALTER OR REMOVE COPYRIGHT NOTICES OR THIS FILE HEADER.
 * 
 * This file is subject to Asset Store Terms of Service and EULA.
 * Please see http://unity3d.com/company/legal/as_terms for more information.
 */

package com.lostpolygon.unity.bluetoothmediator;

import java.io.IOException;

import com.lostpolygon.unity.bluetoothmediator.interop.UnityEvents;
import com.lostpolygon.unity.bluetoothmediator.interop.LogHelper;

import android.bluetooth.BluetoothServerSocket;
import android.bluetooth.BluetoothSocket;

/**
 * The thread that accepts incoming Bluetooth connections.
 */
class BluetoothMediatorAcceptThread extends Thread {

	/** The BluetoothMediatorServer instance. */
	private final BluetoothMediatorServer mBluetoothMediatorServer;
	// local server socket
	/** The Bluetooth socket used for connecting. */
	private BluetoothServerSocket mBluetoothAcceptSocket;

	/**
	 * Instantiates a new Bluetooth accept thread.
	 * 
	 * @param bluetoothMediatorServer
	 *            the BluetoothMediatorServer instance
	 */
	protected BluetoothMediatorAcceptThread(BluetoothMediatorServer bluetoothMediatorServer) {
		super("BluetoothMediatorAcceptThread");
		mBluetoothMediatorServer = bluetoothMediatorServer;
	}

	/**
	 * Allocates the listening RFCOMM channel.
	 */
	public synchronized void startListening() {
		// Create a new listening server socket
		try {
			mBluetoothAcceptSocket = mBluetoothMediatorServer.getMediatorCallback()
					.getAdapter()
					.listenUsingRfcommWithServiceRecord("BluetoothMediatorInsecure",
						mBluetoothMediatorServer.getMediatorCallback().getSettings().uuid);
		} catch (IOException e) {
			if (BluetoothMediator.isVerboseLog()) {
				LogHelper.logError("Server - Socket listen() failed", this, e);
			}
			cancel();
		}
	}

	/**
	 * @see java.lang.Thread#run()
	 */
	public void run() {
		if (mBluetoothAcceptSocket == null)
			return;

		if (BluetoothMediator.isVerboseLog())
			LogHelper.log("Server - Starting AcceptThread", this);

		BluetoothSocket socket = null;

		// Listen to the server socket if we're not connected
		UnityEvents.listeningStarted();
		while (true) {
			try {
				// This is a blocking call and will only return on a
				// successful connection or an exception
				socket = mBluetoothAcceptSocket.accept();
			} catch (IOException e) {
				if (BluetoothMediator.isVerboseLog()) {
					LogHelper.logError("Server - IOException in mBluetoothAcceptSocket.accept(), canceling", this, e);
				}

				cancel();
				break;
			}

			// If a connection was accepted, notifiyng the server instance
			if (socket != null) {
				mBluetoothMediatorServer.onDeviceConnected(socket, socket.getRemoteDevice());
			}
		}

		if (BluetoothMediator.isVerboseLog())
			LogHelper.log("Server - Ending AcceptThread", this);

		// When listening is canceled
		synchronized (BluetoothMediatorAcceptThread.this) {
			if (mBluetoothAcceptSocket != null) {
				if (BluetoothMediator.isVerboseLog())
					LogHelper.log("Server - Socket cancel " + this, this);

				cancel();
				mBluetoothAcceptSocket = null;
			}

		}
	}

	/**
	 * Cancels the listening process.
	 */
	public synchronized void cancel() {
		if (mBluetoothAcceptSocket != null) {
			try {
				mBluetoothAcceptSocket.close();
				mBluetoothAcceptSocket = null;
			} catch (IOException e) {
				LogHelper.logError("Server - Socket close() failed", this, e);
			}

			UnityEvents.listeningStopped();
		}
	}
}